
(function () {
    if (typeof window.jsb === 'object') {
        //console.log("nhay dc vao main2")
        let ver = "2";
        sys.localStorage.setItem("verNative", ver);
        var hotUpdateSearchPaths = sys.localStorage.getItem('SearchAssets');
        let fileUltil = jsb.fileUtils;
       // jsb.fileUtils.setSearchPaths
        if (hotUpdateSearchPaths) {
            // console.log(hotUpdateSearchPaths);
            var paths = JSON.parse(hotUpdateSearchPaths);
            fileUltil.setSearchPaths(paths);
            paths.forEach((v) => {
                var fileList = [];
                var storagePath = v || '';
                if (storagePath.includes("AllGame") || storagePath.includes("remote-asset")) {
                    var tempPath = storagePath + '_temp/';
                    var baseOffset = tempPath.length;
                    if (fileUltil.isDirectoryExist(tempPath) && !fileUltil.isFileExist(tempPath + 'project.manifest.temp')) {
                        fileUltil.listFilesRecursively(tempPath, fileList);
                        fileList.forEach(srcPath => {
                            var relativePath = srcPath.substr(baseOffset);
                            var dstPath = storagePath + relativePath;

                            if (srcPath[srcPath.length] == '/') {
                                fileUltil.createDirectory(dstPath)
                            }
                            else {
                                if (fileUltil.isFileExist(dstPath)) {
                                    fileUltil.removeFile(dstPath)
                                }
                                fileUltil.renameFile(srcPath, dstPath);
                            }
                        })
                        fileUltil.removeDirectory(tempPath);
                    }
                }

            })

            //   console.log("set searh paths: " + hotUpdateSearchPaths)

        }
    }
})();